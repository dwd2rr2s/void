# Void Hosting — Pterodactyl / Nebula Theme Pack

A brand-new purple/void themed visual pack designed around the supplied Void Hosting artwork.

## Included
- `void-theme.css` — main visual theme
- `void-theme.js` — optional helper that automatically switches to the login background on auth routes
- `palette.txt` — matching Nebula palette values

## Artwork URLs
- Logo: https://i.postimg.cc/9F49MZTP/1e9f2edd-8238-47ca-a016-2fd2a869a576.png
- Login background: https://i.postimg.cc/MGwfdLLD/bc9ed936-ff1e-4569-8b99-d05520d94f96.png
- Main panel background: https://i.postimg.cc/vZLp6gwS/Neon-Lagoon-at-Tropical-Sunset.png

## Recommended Nebula setup
Set the logo and background URLs using Nebula's own branding controls first, then add the CSS in its custom CSS area if your Nebula build exposes one.

If your Nebula installation has a custom JavaScript area, load `void-theme.js` as well. It is optional; the CSS still provides the main theme without it.

## Direct Pterodactyl note
Pterodactyl's frontend bundle and selectors vary by version/theme. This pack intentionally avoids replacing core panel files. If you want a fully compiled drop-in theme, use the exact Pterodactyl + Nebula version you're running and adapt the selectors/build pipeline to that version.

## Visual direction
- Glassy dark violet cards
- Neon purple active states
- High-contrast readable inputs
- No white input flash on focus
- Purple glowing scrollbar
- Login background distinct from main dashboard
- Main background remains visible behind translucent panel surfaces
