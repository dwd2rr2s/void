/* Optional helper for Void theme. Safe visual-only DOM enhancements. */
(() => {
  const applyRouteClass = () => {
    const path = location.pathname.toLowerCase();
    document.body.classList.toggle('void-auth', path.includes('/auth') || path.includes('/login'));
  };
  applyRouteClass();
  window.addEventListener('popstate', applyRouteClass);
  const push = history.pushState;
  history.pushState = function(...args){ const r = push.apply(this,args); setTimeout(applyRouteClass,0); return r; };
  const replace = history.replaceState;
  history.replaceState = function(...args){ const r = replace.apply(this,args); setTimeout(applyRouteClass,0); return r; };
})();
